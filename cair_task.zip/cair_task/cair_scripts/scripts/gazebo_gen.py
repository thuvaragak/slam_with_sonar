import math

link_templ = "sonar_right_"
topic_templ = "sonar/right_"
n = 45

for i in range(1,n+1):
    link_name = link_templ + str(i)
    topic_name =  topic_templ + str(i)
    template = f'<gazebo reference="{link_name}"><sensor type="ray" name="Sonar"><visualize>true</visualize><update_rate>5</update_rate>\n<ray><scan><horizontal><samples>10</samples>\n<resolution>0.1</resolution><min_angle>-0.00436</min_angle>\n<max_angle>0.00436</max_angle></horizontal></scan><range><min>0.01</min><max>10</max><resolution>0.02</resolution></range></ray>\n<plugin filename="libgazebo_ros_range.so" name="gazebo_ros_range"><gaussianNoise>0.005</gaussianNoise>\n<alwaysOn>true</alwaysOn><updateRate>50</updateRate>\n<topicName>{topic_name}</topicName><frameName>{link_name}</frameName>\n<radiation>INFRARED</radiation><fov>0.00872</fov>\n</plugin></sensor></gazebo>'
    print (template, "\n")