#!/usr/bin/env python3
import rospy
import math
from sensor_msgs.msg import Range, LaserScan

class SonarToLaser:
    def __init__(self):
        print ("init_called")
        self.no_of_beams = 45 #in one side left/right
        self.angle_offset = 1 #degrees
        self.total_beams = ((self.no_of_beams * 2)) + 1 # the center beam
        self.total_angle = math.radians(self.total_beams * self.angle_offset)
        self.data = [math.inf] * self.total_beams
        self.intensity = [1] * self.total_beams
        rospy.Subscriber("sonar/sonar",Range, self.subscriber_generator("middle", self.no_of_beams))
        for i in range(1,self.no_of_beams+1):
            topic = "sonar/left_" + str(i)
            rospy.Subscriber(topic, Range, self.subscriber_generator("left", i))
        for i in range(1,self.no_of_beams+1):
            topic = "sonar/right_" + str(i)
            rospy.Subscriber(topic, Range, self.subscriber_generator("right", i))
        rospy.Timer(rospy.Duration(0.1), self.publish_scan)
        self.scan_pub = rospy.Publisher("/sonar_scan", LaserScan, queue_size=10)

    def subscriber_generator(self, type, no):
        def cb(msg):
            if type == "left":
                new_index = self.no_of_beams + no
            elif type == "right":
                new_index =  self.no_of_beams-no
            elif type == "middle":
                new_index = no
            self.data[new_index] = msg.range
        return cb
        

    def publish_scan(self, e):
        scan = LaserScan()
        scan.header.stamp = rospy.Time.now()
        scan.header.frame_id = "laser_link"
        scan.angle_min = -(self.total_angle/2.0)  # start angle of the scan in radians
        scan.angle_max = (self.total_angle/2.0) # end angle of the scan in radians
        scan.angle_increment = math.radians(self.angle_offset)  # angular resolution in radians
        scan.time_increment = 0.001  # time between measurements in seconds
        scan.range_min = 0.0  # minimum range value in meters
        scan.range_max = 10.0  # maximum range value in meters
        scan.ranges = self.data
        scan.intensities = self.intensity
        self.scan_pub.publish(scan)

if __name__ == "__main__":
   rospy.init_node("sonar_to_laser")
   s2l = SonarToLaser()
   rospy.spin()