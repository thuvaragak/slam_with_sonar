import math

link_templ = "sonar_left_"
joint_templ = "sonar_left_joint_"
orientation = 0
sign = 1 #-1 right #1 left
n = 45
ori_offset = 1

for i in range(1,n+1):
    link_name = link_templ + str(i)
    joint_name = joint_templ + str(i)
    orientation += math.radians(ori_offset)
    orientation = orientation * sign
    template = f'<link name="{link_name}"/>\n<joint name="{joint_name}" type="fixed">\n<origin xyz="0.21 0 0" rpy="0 0 {orientation} " />\n<parent link="chassis" /><child link="{link_name}" />\n</joint>'
    print (template,"\n")